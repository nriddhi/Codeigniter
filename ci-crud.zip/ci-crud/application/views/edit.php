<!DOCTYPE html>
<html>
<head>
	<title>CRUD Application</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()."ci-crud/assets/css/bootstrap.min.css"   ?>">
</head>
<body>


<div class="navbar navbar-dark bg-dark">

	<div class="container">

    <a href="<?php echo base_url()."ci-crud"  ?>" class="navbar-brand">CRUD APPLICATION</a>

	</div>

</div>

<div class="container" style="padding-top: 10px">

	<h3>Edit User </h3>

	<hr>


<form method="post" action="<?php echo base_url()."ci-crud/users/edit/".$single_user['user_id']  ?>">
	<div class="row">

	<div class="col-md-6">

<div class="form-group">

<label>Your Name</label>

	<input class="form-control" value="<?php echo set_value('name', $single_user['name']);   ?>" type="text" name="name">

	<?php echo form_error('name');   ?>

</div>

<div class="form-group">

<label>Your Email</label>

	<input class="form-control" type="text" value="<?php echo set_value('email', $single_user['email']);   ?>" name="email">

	<?php echo form_error('email');   ?>

</div>


<div class="form-group">

<button class="btn btn-primary">Update</button>

<a href="<?php echo base_url()."ci-crud"  ?>" class="btn btn-secondary">Cancel</a>

</div>

	</div>

	</div>

	</form>

	</div>


</body>
</html>