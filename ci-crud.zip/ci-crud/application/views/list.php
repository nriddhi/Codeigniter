<!DOCTYPE html>
<html>
<head>
	<title>CRUD Application</title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url()."ci-crud/assets/css/bootstrap.min.css"   ?>">
</head>

<body>


	<div class="navbar navbar-dark bg-dark">

	<div class="container">

    <a href="<?php echo base_url()."ci-crud"  ?>" class="navbar-brand">CRUD APPLICATION</a>

	</div>

</div>

<div class="container" style="padding-top: 10px">
<div class="row">

	<h3>All Users </h3>


	

<div class="col-md-12" style="padding-top: 10px;">

<?php  $success = $this -> session -> userdata('success'); ?>

<?php  if($success != "" ) {  ?>

<div class="alert alert-success"> <?php echo $success; ?>  </div>

<?php }  ?>



	</div>

	

<div class="col-12 text-right"> <a href="<?php echo base_url()."ci-crud/users/create"  ?>" class="btn btn-primary"> Create </a>  </div>

</div>

<hr>

<div class="row">

	<div class="col-md-12">

		<table class="table table-striped">
			
          <tr>
          	
             <th>ID</th>
             <th>Name</th>
             <th>Email</th>
             <th>Edit</th>
             <th>Delete</th>

          </tr>


   <?php   if(!empty($user_datas)): foreach($user_datas as $single_data):     ?>
          <tr>
          	
          	<td>
          <?php echo $single_data['user_id'];   ?>
          	</td>	

          	<td>
          <?php echo $single_data['name'];   ?>
          	</td>	

          	<td>
          <?php echo $single_data['email'];   ?>
          	</td>


          	<td>
            <a href="<?php echo base_url()."ci-crud/users/edit/". $single_data['user_id'];  ?>" class="btn btn-primary"> Edit  </a>
          	</td>


          	<td>
         <a href="<?php echo base_url()."ci-crud/users/delete/". $single_data['user_id'];  ?>" onclick='deleteItem()' class="btn btn-danger"> Delete </a>
          	</td>



          </tr>

      <?php endforeach; else:   ?>

           <h3 style="padding-bottom: 10px;">No Data Available</h3>

        <?php endif;    ?>

		</table>

	</div>


	</div>

</div>

<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>

<script type="text/javascript">
	
function deleteItem() {
    if (confirm("Are you sure?")) {
        // your deletion code
    }
    return false;
}
	
</script>

</body>
</html>