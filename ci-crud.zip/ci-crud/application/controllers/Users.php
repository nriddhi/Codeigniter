<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {


	public function index()

	{

      $this -> load -> model('Users_model');

       $all_users = $this -> Users_model -> all();

       $data = array();

       $data['user_datas'] = $all_users;


       $this -> load -> view('list', $data);

	}

	public function create()
	{
       $this -> load -> model('Users_model');

       $this->form_validation->set_rules('name', 'Name', 'required');

       $this->form_validation->set_rules('email', 'Email', 'required|valid_email');


       if($this ->form_validation-> run() == false)

       {
          $this->load->view('create');

       }

       else

       {
                 $formValues = array();
                 $formValues['name'] = $this -> input -> post('name');
                 $formValues['email'] = $this -> input -> post('email');
                 $formValues['created_at'] = date('Y-m-d');

                 $this -> Users_model -> create($formValues);

                $this->session->set_flashdata('success', 'Record Added Successfully');

                redirect(base_url().'ci-crud/users','refresh');



       }

		
	}



	public function edit($userId)

	{

        $this -> load -> model('Users_model');

         $user = $this -> Users_model -> getUser($userId);

         $data_single = array();

         $data_single['single_user'] = $user;

          $this->form_validation->set_rules('name', 'Name', 'required');

          $this->form_validation->set_rules('email', 'Email', 'required|valid_email');


       if($this ->form_validation-> run() == false)

       {

        $this -> load -> view('edit', $data_single);

       }

       else

       {
                $dataValues= array();

                $dataValues['name'] = $this -> input ->post('name');
                $dataValues['email'] = $this -> input ->post('email');

                $this -> Users_model -> updateUser($userId, $dataValues);

                $this->session->set_flashdata('success', 'Record Updated Successfully');

                redirect(base_url().'ci-crud/users','refresh');

	   }

}




public function delete($userId)


{

  $this -> load ->model('Users_model');

  $this -> Users_model -> userDelete($userId);

   $this->session->set_flashdata('success', 'Record Deleted Successfully');

   redirect(base_url().'ci-crud/users','refresh');

}





}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */