<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {

	public function create($formValues)

	{

      $this -> db -> insert('users', $formValues);

	}


	function all()

	{

   return $this -> db -> get('users') -> result_array();

	}


	function getUser($userId)

	{
         $this -> db -> where('user_id', $userId);

         return $users = $this -> db -> get('users') -> row_array();


	}


	function updateUser($userId, $dataValues)

	{
         $this -> db -> where('user_id', $userId);

         $this -> db -> update('users', $dataValues);


	}



	function userDelete($userId)

	{
     

     $this -> db -> where('user_id', $userId);


     $this -> db -> delete('users');




	}

}

/* End of file Users_model.php */
/* Location: ./application/models/Users_model.php */